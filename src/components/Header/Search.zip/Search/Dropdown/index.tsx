import React from 'react';
import cn from 'classnames';
import s from './Drop.module.scss';
// import useData from '../../../../hooks/useData';
import { TDiscover } from '../../../../interface';
// import Movies from '../../../Movies';
import Loading from '../../../Loading';
// import useDebounce from '../../../../hooks/useDebounce';
// import MovieRow from '../../../MovieRow';
import { Link } from 'react-router-dom';
import { CalendarEvent, PersonFill, StarFill } from 'react-bootstrap-icons';
import convertDate from '../../../../utils/dateToString';

interface IProps {
  list: null | TDiscover[];
  isLoading?: boolean
  className?: string
}

const Dropdown: React.FC<IProps> = ({list, isLoading}) => {

  return (

    <>
      { 
        isLoading ? <Loading /> : (
        <div className='list-group'>
          {
            list && list.map(movie => (
              <div key={movie.id} className={cn("list-group-item", s.row)}>
                <Link to={`/movies/${movie.id}`} className={cn(s.link)}>
                  <div className="row align-items-center">
                    <div className='col-2'>
                      <div className={cn("poster", s.poster)}>
                        <img
                          src={"https://image.tmdb.org/t/p/w500" + movie.poster_path}
                          className="card-img-top card-img-bottom"
                          alt={movie.title}
                        />
                      </div>
                    </div>
            
                    <div className='col-10 pl-0'>
                      <p className={cn(s.title, 'text-white mb-2')}>
                        {movie.title}
                      </p>
                      <p className={cn(s.rating, 'd-flex align-items-center m-0')}>
                        <StarFill size={14} className='fill--primary mr-2' 
                          style={{opacity: (movie.vote_average / 10 ) }}/>
                        <small className='text-secondary mr-3'>{movie.vote_average}</small> 
            
                        <PersonFill size={16} className='fill--secondary mr-2'/>
                        <small className='text-secondary'>{movie.vote_count}</small> 

                        <span style={{marginLeft: 'auto'}}>
                          <CalendarEvent size={14} className='fill--secondary mr-2' />
                          <small className='text-secondary'>
                            { convertDate(movie.release_date) }
                          </small>
                        </span>
                      
                      </p>
                    </div>
                    
                  </div>
                </Link>
              </div>
            ))
          }
        </div>
      )}
    </>
   
  );

};

export default Dropdown;